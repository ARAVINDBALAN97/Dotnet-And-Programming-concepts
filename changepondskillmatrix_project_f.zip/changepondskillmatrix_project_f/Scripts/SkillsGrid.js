


$(document).ready(function () {

    alert("test");
    //debugger;
    $("#gridSkills").jqGrid
    ({

        url: "/Admin/GetSkills",
        datatype: 'json',
        mtype: 'Get',
        //table�header�name���
        colNames: ['Skill_ID', 'Skill_ID', 'Skill_Name', 'Category_ID', 'Category_Name'],
        //colModel�takes�the�data�from�controller�and�binds�to�grid���
        colModel: [
             
       {
           key: true,
           hidden: false,
            name: 'Skill_ID',
            index: 'Skill_ID',
            editable: false
           
       }, {
           key: true,
           hidden: true,
           name: 'Skill_ID',
           index: 'Skill_ID',
           editable: true

       }, {
           key: false,
           name: 'Skill_Name',
           index: 'Skill_Name',
           editable: true
       }, {
           key: true,
           hidden: true,
           name: 'Category_ID',
           index: 'Category_ID',
           editable: true

       },

       {
        key: false,
        name: 'Category_Name',
        index: 'Category_Name',
    editable: true
       }
        ],

        pager: jQuery('#pagerSkills'),
        rowNum: 10,
        rowList: [10, 20, 30, 40],
        height: '100%',
        viewrecords: true,
        caption: 'Skills',
        loadonce:false,
        emptyrecords: 'No�records�to�display',
        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
        multiselect: false
        //pager-you�have�to�choose�here�what�icons�should�appear�at�the�bottom��
        //like�edit,create,delete�icons��
    }).navGrid('#pagerSkills',
    {
        edit: true,
        add: true,
        del: true,
        search: true,
        refresh: true
    }, {
        //�edit�options��
        zIndex: 100,
        url: '/Admin/EditSkills',
        closeOnEscape: true,
        closeAfterEdit: true,
        recreateForm: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�add�options��
        zIndex: 100,
        url: "/Admin/CreateSkills",
        closeOnEscape: true,
        closeAfterAdd: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�delete�options��
        zIndex: 100,
        url: "/Admin/DeleteSkills",
        closeOnEscape: true,
        closeAfterDelete: true,
        recreateForm: true,
        msg: "Are�you�sure�you�want�to�delete�this�task?",
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }

    });

    $("#filter").click(function (event) {
        event.preventDefault();
        filterGrid();
    })
});

function filterGrid() {
    var postdatavalues = $("#gridSkills").jqGrid("getGridParam","data");
    
    //postdatavalues = data;
        
    $('#filterItem').each(function (index, item) {
        postdatavalues[$(item).attr('id')] = $(item).val();
    });
    $('#gridSkills').jqgrid(setGridParam({ postData: postdatavalues, page: 1 })).trigger('reloadGrid');
}








