﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(changepondskillmatrix_project_f.Startup))]
namespace changepondskillmatrix_project_f
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
