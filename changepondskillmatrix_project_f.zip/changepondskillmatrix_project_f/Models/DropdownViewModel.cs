﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace changepondskillmatrix_project_f.Models
{
    public class DropdownViewModel
    {
    
    //    [Key]
    //    public string Skill_ID { get; set; }

    //    public string Skill_Name { get; set; }
    //    public string Category_ID { get; set; }
    //    public List<DropdownViewModel> obj1 { get; set; }
    //    public List<CategoryDropdown> objcat { get; set; }
         
    //}
    //public class CategoryDropdown
    //{
    //    public string Category_ID { get; set; }

    //    public string Category_Name { get; set; }
    

    //}
    public DropdownViewModel()
    {
        this.Tbl_Category = new List<SelectListItem>();
        this.Tbl_Skills = new List<SelectListItem>();
       
    }
 
    public List<SelectListItem> Tbl_Category { get; set; }
    public List<SelectListItem> Tbl_Skills { get; set; }

    public  string Category_ID { get; set; }
    //public string Category_Name { get; set; }
    public string Skill_ID { get; set; }
}
    public class EmployeeScore
    {
         public string EmpID{ get; set; }
        public string  EmployeeName{ get; set; }
                            
       public string Designation{ get; set; }
                             
        public string ReportingPerson{ get; set; }
                               
       public string Category_Name{ get; set; }
       public string  Skill_Name{ get; set; }
       public byte? Score_Rating { get; set; }
       public string Category_ID { get; set; }
       public byte? Score_ID { get; set; }
       public string Score_Description { get; set; }
       public string Skill_ID { get; set; }
      public List<EmployeeScore> objemp { get; set; }

       public EmployeeScore()
    {
        this.Tbl_Category = new List<SelectListItem>();
        this.Tbl_Skills = new List<SelectListItem>();
        this.Tbl_Score_Description = new List<SelectListItem>();
    }
       public List<SelectListItem> Tbl_Score_Description { get; set; }
    public List<SelectListItem> Tbl_Category { get; set; }
    public List<SelectListItem> Tbl_Skills { get; set; }
    }



}