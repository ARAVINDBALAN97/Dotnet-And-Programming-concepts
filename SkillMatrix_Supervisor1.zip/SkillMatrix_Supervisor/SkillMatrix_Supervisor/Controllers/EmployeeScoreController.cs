﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Data.Entity;


namespace SkillMatrix_Supervisor.Controllers
{
    public class EmployeeScoreController : Controller
    {
        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();
        //
        // GET: /EmployeeScore/
        public ActionResult Index()
        {


        
            return View();
        }


        public JsonResult GetEmployee()
        {

            var Employee = (from emp in db.Tbl_EmployeeMaster
                            select new
                            {
                                emp.EmpID,
                                emp.EmployeeName
                            });
            //var Countries = new List<string>();
            //Countries.Add("Australia");
            //Countries.Add("India");
            //Countries.Add("Russia");
            return Json(Employee, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult GetEmployeID(string empId,string empName )
        {


            var EmployeID = (from empID in db.Tbl_EmployeeMaster
                             where empID.EmpID == empId
                             select new
                             {
                                 empID.EmpID
                             });
            //var States = new List<string>();
            //if (!string.IsNullOrWhiteSpace(country))
            //{
            //    if (country.Equals("Australia"))
            //    {
            //        States.Add("Sydney");
            //        States.Add("Perth");
            //    }
            //    if (country.Equals("India"))
            //    {
            //        States.Add("Delhi");
            //        States.Add("Mumbai");
            //    }
            //    if (country.Equals("Russia"))
            //    {
            //        States.Add("Minsk");
            //        States.Add("Moscow");
            //    }
            //}
            return Json(EmployeID, JsonRequestBehavior.AllowGet);
        }   
        //public JsonResult employeesscores(string sidx, string sord, int page, int rows, string searchString)
        //{
        //    //#1 Create Instance of DatabaseContext class for Accessing Database.  


        //    //#2 Setting Paging  
        //    int pageIndex = Convert.ToInt32(page) - 1;
        //    int pageSize = rows;

        //    //#3 Linq Query to Get Customer  
        //    var Result = (from es in db.Tbl_Employee_Score
        //                  join ct in db.Tbl_Category on es.Category_Name equals ct.Category_ID
        //                  join sk in db.Tbl_Skills on es.Skill_Name equals sk.Skill_ID
        //                  join emp in db.Tbl_EmployeeMaster on es.EmpID equals emp.EmpID

        //                  select new
        //                  {
        //                      es.EmpID,
        //                      ct.Category_Name,
        //                      sk.Skill_Name,
        //                      es.Score_Rating,
        //                      emp.EmployeeName

        //                  });


        //    //#4 Get Total Row Count  
        //    int totalRecords = Result.Count();
        //    var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

        //    //#5 Setting Sorting  
        //    if (sord.ToUpper() == "DESC")
        //    {
        //        Result = Result.OrderByDescending(s => s.EmpID);
        //        Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
        //    }
        //    else
        //    {
        //        Result = Result.OrderBy(s => s.EmpID);
        //        Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
        //    }
        //    //based on login employeeview
        //    //if (!string.IsNullOrEmpty(Supervisor_ID))
        //    //{
        //    //    Result = Result.Where(m => m.ReportingPerson == Supervisor_ID);
        //    //}
        //    //#6 Setting Search  
        //    if (!string.IsNullOrEmpty(searchString))
        //    {
        //        Result = Result.Where(m => m.EmpID == searchString);
        //    }
        //    //#7 Sending Json Object to View.  
        //    var jsonData = new
        //    {
        //        total = totalPages,
        //        page,
        //        records = totalRecords,
        //        rows = Result
        //    };
        //    return Json(jsonData, JsonRequestBehavior.AllowGet);

        //}
        //public string EditEmployee(Tbl_EmployeeMaster Employee, Tbl_Role Roless)
        //{


        //    Employee.Role = (Roless.RoleID);




        //    string msg;
        //    try
        //    {

        //        if (ModelState.IsValid)
        //        {

        //            db.Entry(Employee).State = EntityState.Modified;
        //            db.SaveChanges();
        //            msg = "Saved Successfully";

        //        }
        //        else
        //        {
        //            msg = "Some Validation ";
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        msg = "Error occured:" + ex.Message;
        //    }
        //    return msg;
        //}
	}
}