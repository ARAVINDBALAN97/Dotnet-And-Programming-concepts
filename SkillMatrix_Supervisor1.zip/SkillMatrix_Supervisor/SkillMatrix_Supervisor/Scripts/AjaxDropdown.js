﻿$(function () {

    AjaxCall('/EmployeeScore/GetEmployee', null).done(function (response) {
        if (response.length > 0) {
            $('#EmployeeDropDownList').html('');  
            var options = '';
            options += '<option value="Select">Select</option>';
            for (var i = 0; i < response.length; i++) {
                options += '<option value="' + response[i] + '">' + response[i] + '</option>';
            }
            $('#EmployeeDropDownList').append(options);

        }
    }).fail(function (error) {
        alert(error.StatusText);
    });

    $('#EmployeeDropDownList').on("change", function () {
        var country = $('#EmployeeDropDownList').val();
        var obj = { country: country };
        AjaxCall('/EmployeeScore/GetEmployeID', JSON.stringify(obj), 'POST').done(function (response) {
            if (response.length > 0) {
                $('#EmployeIDDropDownList').html('');
                var options = '';
                options += '<option value="Select">Select</option>';
                for (var i = 0; i < response.length; i++) {
                    options += '<option value="' + response[i] + '">' + response[i] + '</option>';
                }
                $('#EmployeIDDropDownList').append(options);

            }
        }).fail(function (error) {
            alert(error.StatusText);
        });
    });

});

function AjaxCall(url, data, type) {
    return $.ajax({
        url: url,
        type: type ? type : 'GET',
        data: data,
        contentType: 'application/json'
    });
}