﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(cp_ep.Startup))]
namespace cp_ep
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
