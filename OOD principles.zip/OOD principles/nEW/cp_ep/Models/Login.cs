﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
namespace cp_ep.Models
{
    public class Login
    {
        [Key]
        public int User_Name { get; set; }
        public string Password { get; set; }
       
    }
}