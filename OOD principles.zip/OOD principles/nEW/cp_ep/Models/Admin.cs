﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace cp_ep.Models
{
    public class skillmatrix
    {
        public Admin Admin_obj { get; set; }
        public Employee_Details Emp_obj { get; set; }
    }



    public class Admin 
    {
        [Key]
        public int Employee_Id { get; set; }
        public String Start_Date { get; set; }
        public String End_Date { get; set; }
    }
}