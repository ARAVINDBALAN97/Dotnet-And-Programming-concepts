﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace cp_ep.Models
{
    public class Employee_Details 
    {
        [Key]
        public int Employee_Id { get; set; }
        public String Employee_Name { get; set; }
        public String Date_Of_Joining { get; set; }
        public String Designation { get; set; }
        public String Reporting_Person { get; set; }
        public List<Employee_Details> Empoblst { get; set; }
    }
   /* public class List<Employee_Details>
    {
        [Key]
        public int Employee_Id { get; set; }
        public String Employee_Name { get; set; }
        public String Date_Of_Joining { get; set; }
        public String Designation { get; set; }
        public String Reporting_Person { get; set; }
      

    }*/
    public class UpdateViewDetails
    {
        [Display(Name = "Employee_Id")]
        public int Employee_Id { get; set; }

       
     //   [DataType(DataType.Password)]
        [Display(Name = "Employee_Name")]
        public string Employee_Name { get; set; }

        [Display(Name = "Date_Of_Joining")]
        public DateTime Date_Of_Joining { get; set; }

        [Display(Name = "Designation")]
        public string Designation { get; set; }

        [Display(Name = "Reporting_Person")]
        public int Reporting_Person { get; set; }
    }
}