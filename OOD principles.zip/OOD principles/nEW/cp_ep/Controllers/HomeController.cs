﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using cp_ep.Models;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Threading.Tasks;

namespace cp_ep.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult Login_page()
        {
            return View();
        }
        public ActionResult Admin_Home()
        {
            return View();
        }
        public ActionResult Admin_Action()
        {
            Employee_Details Emp = new Employee_Details();
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("Select EmpID,EmployeeName,DOJ,Designation,ReportingPerson from employeemaster", con);
                
                    //cmd.CommandType = CommandType.StoredProcedure;
                   // cmd.Parameters.AddWithValue("@status", "GET");
            
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    da.Fill(ds);
                    List<Employee_Details> Emp_list = new List<Employee_Details>();
                   for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        Employee_Details uobj = new Employee_Details();
                        uobj.Employee_Id = Convert.ToInt32(ds.Tables[0].Rows[i]["EmpID"].ToString());
                        uobj.Employee_Name = ds.Tables[0].Rows[i]["EmployeeName"].ToString();
                       
                        uobj.Designation = ds.Tables[0].Rows[i]["Designation"].ToString();
                         uobj.Reporting_Person = ds.Tables[0].Rows[i]["ReportingPerson"].ToString();
                         uobj.Date_Of_Joining = ds.Tables[0].Rows[i]["DOJ"].ToString();
                        Emp_list.Add(uobj);
                    }
                   // Emp.Empoblst = Emp_list;
                    Emp.Empoblst = Emp_list;
            
                
                con.Close();

                return View(Emp);
        }
       /* [HttpPost]
        public ActionResult InsertUserDetails(UserDetails user)
        {
            UserDetails objuser = new UserDetails();
            using (SqlConnection con = new SqlConnection("Data Source=Suresh;Integrated Security=true;Initial Catalog=MySamplesDB"))
            {
                using (SqlCommand cmd = new SqlCommand("usercrudoperations", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@name", user.UserName);
                    cmd.Parameters.AddWithValue("@education", user.Education);
                    cmd.Parameters.AddWithValue("@location", user.Location);
                    cmd.Parameters.AddWithValue("@status", "INSERT");
                    con.Open();
                    ViewData["result"] = cmd.ExecuteNonQuery();
                    con.Close();
                }
            }
            return View();
            
        }*/
        
        public ActionResult Edit_Details(int id)
        {

            Employee_Details Emp = new Employee_Details();
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("Select EmpID,EmployeeName,DOJ,Designation,ReportingPerson from employeemaster where EmpID=@EmpID", con);
            cmd.Parameters.AddWithValue("@EmpID", id);
            //cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@status", "GET");

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            List<Employee_Details> Emp_list = new List<Employee_Details>();
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Employee_Details uobj = new Employee_Details();
                uobj.Employee_Id = Convert.ToInt32(ds.Tables[0].Rows[i]["EmpID"].ToString());
                uobj.Employee_Name = ds.Tables[0].Rows[i]["EmployeeName"].ToString();

                uobj.Designation = ds.Tables[0].Rows[i]["Designation"].ToString();
                uobj.Reporting_Person = ds.Tables[0].Rows[i]["ReportingPerson"].ToString();
                uobj.Date_Of_Joining = ds.Tables[0].Rows[i]["DOJ"].ToString();
                Emp_list.Add(uobj);
            }
            // Emp.Empoblst = Emp_list;
            Emp.Empoblst = Emp_list;


            con.Close();

            return View(Emp);
        }
     //   [HttpPost]
       // [AllowAnonymous]
       // [ValidateAntiForgeryToken]
        public ActionResult Update_Details(UpdateViewDetails model, string returnUrl,int id)
        {
            Employee_Details Emp = new Employee_Details();
            DataSet ds = new DataSet();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCon"].ConnectionString);
            SqlCommand cmd = new SqlCommand("Update employeemaster set Designation=@Designation,ReportingPerson=@ReportingPerson where EmpID=@EmpID", con);
          cmd.Parameters.AddWithValue("@EmpID",id);
            cmd.Parameters.AddWithValue("@Designation",model.Designation);
            cmd.Parameters.AddWithValue("@ReportingPerson",model.Reporting_Person);
            //cmd.CommandType = CommandType.StoredProcedure;
            // cmd.Parameters.AddWithValue("@status", "GET");

            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(ds);
            //List<Employee_Details> Emp_list = new List<Employee_Details>();
            //for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            //{
            //    Employee_Details uobj = new Employee_Details();
            //    uobj.Employee_Id = Convert.ToInt32(ds.Tables[0].Rows[i]["EmpID"].ToString());
            //    uobj.Employee_Name = ds.Tables[0].Rows[i]["EmployeeName"].ToString();

            //    uobj.Designation = ds.Tables[0].Rows[i]["Designation"].ToString();
            //    uobj.Reporting_Person = ds.Tables[0].Rows[i]["ReportingPerson"].ToString();
            //    uobj.Date_Of_Joining = ds.Tables[0].Rows[i]["DOJ"].ToString();
            //    Emp_list.Add(uobj);
            //}
            // Emp.Empoblst = Emp_list;
           // Emp.Empoblst = Emp_list;


            con.Close();

            return View("Admin_Home");

        }

        public ActionResult delete_Details()
        {
            return View("Admin_Action");
        }

    }
}