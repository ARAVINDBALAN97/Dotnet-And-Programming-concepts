﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesSystem
{
    public delegate void addition(int a, int b);
    public class DelegatesExamples
    {
        

        public void add(int a, int b)
        {
            Console.WriteLine("The two sum of numbers are {0}", a + b);
        }
    }

}
