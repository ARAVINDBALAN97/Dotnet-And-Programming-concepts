﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            DelegatesExamples del1 = new DelegatesExamples();
            addition obj1 = new addition(del1.add);
            obj1(100, 2);

            DelegateExamples2 del2 = new DelegateExamples2();
            DelegateAnonymous delegateAnonymous = delegate(int a, int b)
            {
                return a + b;
            };

            int answer = delegateAnonymous(100, 32);
            Console.WriteLine("The Answer of anonymous {0}", answer);


            DelegateExample3 del3 = new DelegateExample3();
            DelegateLambda delegateLambda = (a, b) => a + b;
            int answer2 = delegateLambda(12, 45);
            Console.WriteLine("The Answer of anonymous {0}", answer2);

            FuncDelegate fundel4 = new FuncDelegate();
            Func<int, int, int> mydelegate = (a, b) => a + b;
            int result4 = mydelegate(10, 20);
            Console.WriteLine("The Answer of anonymous {0}", result4);


            Console.ReadLine();
        }
    }
}
