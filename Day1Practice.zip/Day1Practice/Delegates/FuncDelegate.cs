﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesSystem
{

    public delegate Tresult FuncAddition<T1,T2,Tresult>(T1 arg1,T2 arg2);
    public class FuncDelegate
    {
    }
}
