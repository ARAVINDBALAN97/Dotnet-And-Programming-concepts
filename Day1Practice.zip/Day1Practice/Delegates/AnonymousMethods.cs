﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesSystem
{
    public delegate int DelegateAnonymous(int a, int b);

    public class DelegateExamples2
    {
         
    }
}
