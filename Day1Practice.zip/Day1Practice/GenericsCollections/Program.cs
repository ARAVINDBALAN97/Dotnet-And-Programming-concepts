﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericExamples1<int> list = new GenericExamples1<int>();
            GenrericClassExample<string> list1 = new GenrericClassExample<string>();
        }

    }
}
