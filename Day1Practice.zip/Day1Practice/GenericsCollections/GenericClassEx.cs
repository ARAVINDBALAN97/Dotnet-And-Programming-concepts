﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericsCollections
{
   public class GenrericClassExample <T> where T :class
    {
    }
}
