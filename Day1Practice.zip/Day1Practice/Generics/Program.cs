﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {
            GenericsExamples <int>  id = new GenericsExamples<int>();
            id.Id = 3370;
            GenericsExamples<string> name = new GenericsExamples<string>();
            name.Name = "Aravind";

            GenericsExamples<float> salary = new GenericsExamples<float>();
            salary.Salary = 1200.35f;

            Console.WriteLine(id.Id);
            Console.WriteLine(name.Name);
            Console.WriteLine(salary.Salary);
            Console.ReadLine();

        }
    }
}
