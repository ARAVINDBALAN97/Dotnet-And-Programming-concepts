﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    class program
    {
        static void Main(string[] args)
        {
            program1 pg1 = new program1();
            pg1.hashTableExample();

            program2 pg2 = new program2(); 
            pg2.arrayListExample();

            program3 pg3 = new program3();
            pg3.stackExample();

            program4 pg4 = new program4();
            pg4.queueExample();


            program5 pg5 = new program5();
            pg5.sortedListExample();

            Console.ReadKey();
        }

   
        
    }
}
