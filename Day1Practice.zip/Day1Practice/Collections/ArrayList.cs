﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
  public   class program2
    {
        public void arrayListExample()
        {
            ArrayList array1 = new ArrayList();
            array1.Add("Aravind");
            array1.Add(3370);
            array1.Add("Dot.Net Developer");
            //array1.Remove("Aravind");


            IList array2 = new ArrayList() { "AShok", 1234, "Progammer" };

            array1.AddRange(array2);


            for (int i = 0; i < array1.Count; i++)

                Console.WriteLine("Number of Items in : {0}", array1[i]);


            Console.WriteLine("Count of the Array is {0}", array1.Count);
            Console.WriteLine("Count of the Array is {0}", array2.Count);
            Console.WriteLine("Capacity of the Array is {0}", array1.Capacity);


            Console.ReadLine();
        }
    }
}
