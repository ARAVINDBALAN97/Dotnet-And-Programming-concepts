﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    public class program3
    {
        public void stackExample()
        {
            Stack st = new Stack();

            st.Push("Aamir");
            st.Push("Dharman");
            st.Push("Sadham");
            st.Push("Harish");

            Console.Write("Current stack: ");
            foreach (var c in st)
            {
                Console.Write(c + " ");
            }
            Console.WriteLine();

            st.Push("Balaji");
            st.Push("Barani kumar");
            Console.Write("The next poppable value in stack: {0}", st.Peek());
            Console.Write("Current stack: ");

            foreach (var c in st)
            {
                Console.Write(c + " ");
            }

            Console.WriteLine();

            Console.Write("Removing values ");
            st.Pop();
            st.Pop();
            st.Pop();

            Console.Write("Current stack: ");
            foreach (var c in st)
            {
                Console.Write(c + " ");
            }
        }
    }
}
