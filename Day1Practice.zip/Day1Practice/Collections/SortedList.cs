﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    class program5
    {
        public void sortedListExample()
        {
            SortedList sortedList = new SortedList();
            sortedList.Add("one", 1);
            sortedList.Add("two", 2);
            sortedList.Add("three", 3);
            sortedList.Add("four", 4);

            for (int i = 0; i < sortedList.Count; i++)
            {
                Console.WriteLine("key: {0}, value: {1}", sortedList.GetKey(i), sortedList.GetByIndex(i));
            }
        }
    }
}
