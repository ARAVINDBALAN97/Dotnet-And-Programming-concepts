﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
    class program4
    {
        public void queueExample()
        {
            Queue q = new Queue();

            q.Enqueue("Aravind");
            q.Enqueue("Ashok");
            q.Enqueue("Arun");
            q.Enqueue("Ashly");

            Console.WriteLine("Current queue: ");
            foreach (var name in q) 
             Console.Write(name + " ");

            Console.WriteLine();
            q.Enqueue("Sadham");
            q.Enqueue("Aamir");
            Console.WriteLine("Current queue: ");
            foreach (var name in q) 
            Console.Write(name + " ");

            Console.WriteLine();
            Console.WriteLine("Removing some values ");

            
            var ch = q.Dequeue();
            Console.WriteLine("The removed value: {0}", ch);
            ch = q.Dequeue();
            Console.WriteLine("the removed value: {0}", ch);

            Console.ReadKey();
            
        }
    }
}
