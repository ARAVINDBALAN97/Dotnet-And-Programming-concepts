﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Collections
{
   public  class program1
    {
        public void hashTableExample()
        {
            Hashtable hashT1 = new Hashtable();

            hashT1.Add(1, "Aravind");
            hashT1.Add(2, "Arun");
            hashT1.Add(3, "Ashok");
            hashT1.Add(4, "Amudhan");
            hashT1.Add(5, "Adhithiya");


            ICollection k = hashT1.Keys;

            foreach (var s in k)
                Console.WriteLine(hashT1[s]);


            foreach (DictionaryEntry d in hashT1)
                Console.WriteLine("{0} {1}" ,d.Key, d.Value);

            Console.WriteLine("Number of elements: {0}", hashT1.Count);

            Console.ReadLine();

        }
    }
}
