﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeController.Models;
using System.Web.Routing;
namespace AuthorizeController.Infrastructure
{
    public class CustomAuthorizeAttribute : AuthorizeAttribute
    {
        
        public   string[] allowedroles;
        public CustomAuthorizeAttribute (params string[] roles)
        {
            this.allowedroles = roles;
        }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool authorize = false;
            var userId = Convert.ToString(httpContext.Session["UserName"]);

                if(!string.IsNullOrEmpty(userId))
                {
                    using(var context=new Aravind_traineeEntities2())
                    {
                        var userroles = (from logintbl in context.tbl_login
                                         join mastertbl in context.tbl_master on logintbl.username equals mastertbl.person_id
                                         where mastertbl.person_id == userId
                                       select new {
                                           mastertbl.Name,
                                           mastertbl.Domain,
                                           mastertbl.Reportingperson
                                       }).FirstOrDefault();

                        foreach (var item in allowedroles)
                        {    
                            if(item == userroles.Name && item==userroles.Domain && item ==userroles.Reportingperson )
                                return true;
                            
                               
                        }
                    }
                }
                return authorize;
        }
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(
               new RouteValueDictionary  
               {  
                    { "controller", "Home" },  
                    { "action", "index" }  
               });
        }  
    }
}