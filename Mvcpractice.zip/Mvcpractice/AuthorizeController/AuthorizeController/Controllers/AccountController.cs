﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AuthorizeController.Models;
using System.Web.Security;



namespace AuthorizeController.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        Aravind_traineeEntities2 db = new Aravind_traineeEntities2();
        // GET: /Account/
        public ActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Login(tbl_login user)
        {
            var count = db.tbl_login.Where(u => u.username == user.username && u.userpassword == user.userpassword).Count();

            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(user.username, false);
                FormsAuthentication.SetAuthCookie(user.userid, false);
                if (user.username=="3353")
                {
                    Session["Username"] = user.username;
                    Session["UserId"] = user.userid;
                    return RedirectToAction("Index", "Employee");  
                }
                else if(user.username=="3370")
                {
                    Session["Username"] = user.username;
                    Session["UserId"] = user.userid;
                    return RedirectToAction("Index", "Master");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                TempData["message"] = "U r not Authorized to this page";

                return View();
            }
        }
        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
	}
}