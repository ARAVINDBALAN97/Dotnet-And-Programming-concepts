﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
namespace SkillMatrix_Supervisor.Models
{
    public class DropdownViewModel
    {

        //    [Key]
        //    public string Skill_ID { get; set; }

        //    public string Skill_Name { get; set; }
        //    public string Category_ID { get; set; }
        //    public List<DropdownViewModel> obj1 { get; set; }
        //    public List<CategoryDropdown> objcat { get; set; }

        //}
        //public class CategoryDropdown
        //{
        //    public string Category_ID { get; set; }

        //    public string Category_Name { get; set; }


        //}
        public DropdownViewModel()
        {
            this.Tbl_Category = new List<SelectListItem>();
            this.Tbl_Skills = new List<SelectListItem>();

        }

        public List<SelectListItem> Tbl_Category { get; set; }
        public List<SelectListItem> Tbl_Skills { get; set; }

        public string Category_ID { get; set; }
        //public string Category_Name { get; set; }
        public string Skill_ID { get; set; }
    }
    public class EmployeeScore
    {
        [Display(Name = "Employee Wise")]
        public string EmpID { get; set; }

        public string EmployeeName { get; set; }

        public string Designation { get; set; }

        public string ReportingPerson { get; set; }

        [Display(Name = "Category Wise")]
        public string Category_Name { get; set; }
        [Display(Name = "Skill Wise")]
        public string Skill_Name { get; set; }
        [Display(Name = "Score Wise")]
        public byte? Score_Rating { get; set; }
        public string Category_ID { get; set; }
        public byte? Score_ID { get; set; }
        public string Score_Description { get; set; }
        public string Skill_ID { get; set; }
        public List<EmployeeScore> objemp { get; set; }

        public EmployeeScore()
        {
            this.Tbl_Category = new List<SelectListItem>();
            this.Tbl_Skills = new List<SelectListItem>();
            this.Tbl_Score_Description = new List<SelectListItem>();
        }
        public List<SelectListItem> Tbl_Score_Description { get; set; }
        public List<SelectListItem> Tbl_Category { get; set; }
        public List<SelectListItem> Tbl_Skills { get; set; }
    }
    public class ReportEmployeeScore
    {

        // data.EmpID,
        //                  data.EmployeeName,

        //               data.Designation,

        //                data.ReportingPerson,

        //                data.Category_Name,
        //                data.Skill_Name,
        //                       data.Score_Rating 
        public string EmpID { get; set; }
        public string EmployeeName { get; set; }

        public string Designation { get; set; }

        public string ReportingPerson { get; set; }

        public string Category_Name { get; set; }
        public string Skill_Name { get; set; }
        public byte? Score_Rating { get; set; }
        public List<ReportEmployeeScore> reportobj { get; set; }

    }


}