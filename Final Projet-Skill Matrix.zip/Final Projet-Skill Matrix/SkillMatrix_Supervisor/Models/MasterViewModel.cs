﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SkillMatrix_Supervisor.Models
{
    public class MasterViewModel
    {
        public MasterViewModel()
        {
            this.Categories = new List<SelectListItem>();
            this.Skills = new List<SelectListItem>();
            this.Scores = new List<SelectListItem>();
            this.Employees = new List<SelectListItem>();
        }

        public List<SelectListItem> Categories { get; set; }
        public List<SelectListItem> Skills { get; set; }
        public List<SelectListItem> Scores { get; set; }
        public List<SelectListItem> Employees { get; set; }

        [Display(Name = "Employee ID ")]
        public string EmpID { get; set; }
        public string Category_ID { get; set; }
        public string Skill_ID { get; set; }
        public int Score_ID { get; set; }

        [Display(Name = "Employee Name")]
        public string EmployeeName { get; set; }

        [Display(Name = "CategoryName")]
        public string Category_Name { get; set; }

        [Display(Name = "ScoreDescription")]
        public int Score_Description { get; set; }


        [Display(Name = "SkillName")]
        public string Skill_Name { get; set; }
        //public string Category_ID { get; set; }
        //public string Skill_ID { get; set; }
        //public int Score_ID { get; set; }



        //public MasterViewModel()
        //{
        //    this.Tbl_Category = new List<SelectListItem>();
        //    this.Tbl_Skills = new List<SelectListItem>();
        //    this.Tbl_Score_Description = new List<SelectListItem>();
        //    this.Tbl_EmployeeMaster = new List<SelectListItem>();
        //}
        //public List<SelectListItem> Tbl_EmployeeMaster { get; set; }
        //public List<SelectListItem> Tbl_Category { get; set; }
        //public List<SelectListItem> Tbl_Skills { get; set; }
        //public List<SelectListItem> Tbl_Score_Description { get; set; }

        //[Display(Name = "Employee ID ")]
        //public string EmpID { get; set; }
        // [Display(Name = "Employee Name")]
        //public string EmployeeName { get; set; }


        //public string Category_ID { get; set; }
        ////public string Category_Name { get; set; }
        //public string Skill_ID { get; set; }
        // [Display(Name = "CategoryName")]
        //public string Category_Name { get; set; }
        // [Display(Name = "SkillName")]
        //public string Skill_Name { get; set; }
        // [Display(Name = "ScoreDescription")]
        //public int Score_Description { get; set; }
        //public int Score_ID { get; set; }
    }
}