﻿
$(function () {
    if ($("#Skill_ID option").length > 1) {
        $("#Skill_ID").removeAttr("disabled");
    }

    if ($("#Skill_ID option").length > 2) {
        $("#Score_ID").removeAttr("disabled");
    }


});
