


$(document).ready(function ()
{
 
    //debugger;
    $("#gridCategory").jqGrid
    ({
        
        url: "/Admin/GetCategory",
        datatype: 'json',
        mtype: 'Get',
        //table�header�name���
        colNames: ['Category_ID','Category_ID', 'Category_Name'],
        //colModel�takes�the�data�from�controller�and�binds�to�grid���
        colModel: [
        {
            key: true,
            hidden: false,
            name: 'Category_ID',
            index: 'Category_ID',
            editable: false
        },
        {
            key: true,
            hidden: true,
            name: 'Category_ID',
            index: 'Category_ID',
            editable: true
        }, {
            key: false,
            name: 'Category_Name',
            index: 'Category_Name',
            editable: true
        }],

        pager: jQuery('#pagerCategory'),
        rowNum: 10,
        rowList: [10, 20, 30, 40],
        height: '100%',
        viewrecords: true,
        caption: 'Category',
        emptyrecords: 'No�records�to�display',
        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
        multiselect: false
        //pager-you�have�to�choose�here�what�icons�should�appear�at�the�bottom��
        //like�edit,create,delete�icons��
    }).navGrid('#pagerCategory',
    {
        edit: true,
        add: true,
        del: true,
        search: false,
        refresh: true
    }, {
        //�edit�options��
        zIndex: 100,
        url: '/Admin/EditCategory',
        closeOnEscape: true,
        closeAfterEdit: true,
        recreateForm: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�add�options��
        zIndex: 100,
        url: "/Admin/CreateCategory",
        closeOnEscape: true,
        closeAfterAdd: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�delete�options��

        url: "/Admin/Delete",
            closeOnEscape: true,
            closeAfterDelete: true,
            recreateForm: true,
            msg: "Are�you�sure�you�want�to�delete�this�task?",
            afterComplete: function (response) {
                if (response.responseText) {
                    alert(response.responseText);
                }
            }
        })
});

////        zIndex: 100,
////        url: "/Admin/Delete",
////        closeOnEscape: true,
////        closeAfterDelete: true,
////        recreateForm: true,
////        msg: "Are�you�sure�you�want�to�delete�this�task?",
////        afterComplete: function (response) {
////            if (response.responseText) {
////                alert(response.responseText);
////            }
////        }

////    });
////});






