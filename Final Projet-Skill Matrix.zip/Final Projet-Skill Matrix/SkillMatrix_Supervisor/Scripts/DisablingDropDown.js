﻿
$(document).ready(function () {
    
    $("#empid").change(function(){
    
    
        if ($("#empid").val != null) {
            $(".Dropdown").attr("disabled", "disabled");
    }
        else 
        {
            $(".Dropdown").removeattr("disabled");
        }
       


    });


         
        });
