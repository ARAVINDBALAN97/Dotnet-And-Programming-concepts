﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using SkillMatrix_Supervisor.Infrastructure;
using System.Data.Entity;

using System.IO;

using System.Data;
using System.Web.UI.WebControls;
using System.Web.UI;


namespace SkillMatrix_Supervisor.Controllers
{

    [CustomAuthenticationFilter]
    [CustomAuthorizeFilter(Roles: "Admin")]
    [Authorize(Roles = "Admin")]
    public class AdminController : Controller
    {

        static List<ReportEmployeeScore> reportobj = new List<ReportEmployeeScore>();
        // GET: /Admin/
        public ActionResult Adminhome()
        {
            return View();
        }
        public static string catid, skillid, Empid;
        public static byte? scoreid;
        //AdminController()
        //{
        //    this.skillid = "";
        //    this.catid = "";
        //}

        public ActionResult ViewCategory()
        {

            return View();
        }


        Db_Ep_SkillMatrix_ProjectEntities dbobj = new Db_Ep_SkillMatrix_ProjectEntities();

        public JsonResult GetCategory(string sord, int page, int rows)
        {



            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = dbobj.Tbl_Category.Select(
                a => new
                {
                    a.Category_ID,
                    a.Category_Name,


                });

            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Category_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Category_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }




        [HttpPost]
     //   [ValidateAntiForgeryToken]
        [SessionOut]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        
        public string CreateCategory(Tbl_Category obj)
        {

            var idvalue = "";

            var results = dbobj.Tbl_Category.Select(x => x.Category_ID).ToList();
            foreach (var i in results)
            {
                idvalue = i;
            }
            var cat_id = Convert.ToInt32(idvalue) + 1;
            obj.Category_ID = Convert.ToString(cat_id);

            //  var s=dbobj.Tbl_Category.Select(x => x.Category_ID).LastOrDefault();

            //   var results = from user in dbobj.Tbl_Category

            //   select user;

            //  string p = results.LastOrDefault().Category_ID;
            //   var m = Convert.ToInt32(p) + 1;
            //  obj.Category_ID = Convert.ToString(m);
            string msg;
            var duplicate = dbobj.Tbl_Category.Select(x => x).ToList();
            int cnt = 0;
            foreach (var i in duplicate)
            {
                if ((((Convert.ToString(i.Category_Name)).ToUpper() == obj.Category_Name)) || (((Convert.ToString(i.Category_Name)).ToLower() == obj.Category_Name)))
                    cnt = cnt + 1;
            }

            try
            {
                if (ModelState.IsValid)
                {
                    if (cnt == 0)
                    {
                        dbobj.Tbl_Category.Add(obj);

                        dbobj.SaveChanges();
                        msg = "Saved Successfully";
                    }
                    else
                    {
                        msg = "your given data already exists";
                    }
                }
                else
                {
                    msg = "Validation data not successfully";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditCategory(Tbl_Category obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string Delete(string id)
        {
            Tbl_Category list = dbobj.Tbl_Category.Find(id);
            dbobj.Tbl_Category.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }

        //----------------------------------------------viewskills---------------------------------------------------
        public ActionResult FetchSkills()
        {

            DropdownViewModel model = new DropdownViewModel();
            foreach (var Category in dbobj.Tbl_Category)
            {
                model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
            }
            return View(model);
        }

        [HttpPost]
        [SessionOut]
    //    [ValidateAntiForgeryToken]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult FetchSkills(string Category_ID, string Skill_ID)
        {
            catid = Category_ID;
            skillid = Skill_ID;
            DropdownViewModel model = new DropdownViewModel();
            {


                foreach (var Category in dbobj.Tbl_Category)
                {
                    model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
                }

                if (Category_ID != "")
                {
                    var Skills = (from Skill in dbobj.Tbl_Skills
                                  where Skill.Category_ID == Category_ID
                                  select Skill).ToList();
                    foreach (var Skill in Skills)
                    {
                        model.Tbl_Skills.Add(new SelectListItem { Text = Skill.Skill_Name, Value = Skill.Skill_ID });
                    }


                }


                return View(model);
            }
        }



        [HttpPost]
        [SessionOut]
        public ActionResult ViewSkills()
        {

            return View();
        }


        //public ActionResult FetchSkills()
        //{
        //    DropdownViewModel model = new DropdownViewModel();

        //    model.obj1 = getDetails();
        //    model.objcat = getCategoryDetails();
        //    return View(model);
        //}

        //[HttpPost]
        //public ActionResult FetchSkills(string Category_ID, string Skill_ID)
        //{



        //public List<DropdownViewModel> getDetails()
        //{
        //    List<DropdownViewModel> result = new List<DropdownViewModel>();

        //    var obj = dbobj.Tbl_Skills.Select(x => x).ToList();
        //    if (obj != null && obj.Count() > 0)
        //    {
        //        foreach (var data in obj)
        //        {
        //            DropdownViewModel model = new DropdownViewModel();
        //            model.Category_ID = data.Category_ID;
        //            model.Skill_ID = data.Skill_ID;
        //            model.Skill_Name = data.Skill_Name;
        //            result.Add(model);
        //        }
        //    }
        //    return result;
        //}

        public List<EmployeeScore> getEmpScoreDetails()
        {
            List<EmployeeScore> result = new List<EmployeeScore>();

            var obj = (from ep in dbobj.Tbl_Employee_Score
                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID



                       select new
                       {
                           ep.EmpID,
                           sc.EmployeeName,

                           sc.Designation,

                           sc.ReportingPerson,

                           c.Category_Name,
                           m.Skill_Name,
                           ep.Score_Rating
                       }).ToList();
            if (obj != null && obj.Count() > 0)
            {
                foreach (var data in obj)
                {
                    EmployeeScore model = new EmployeeScore();
                    model.EmpID = data.EmpID;
                    model.EmployeeName = data.EmployeeName;
                    model.Designation = data.Designation;
                    model.ReportingPerson = data.ReportingPerson;
                    model.Category_Name = data.Category_Name;
                    model.Skill_Name = data.Skill_Name;
                    model.Score_Rating = data.Score_Rating;

                    result.Add(model);
                }
            }
            return result;
        }




        //public ActionResult GetData()
        //{
        //    var data = from ep in dbobj.Tbl_Category
        //               join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
        //               select new
        //               {
        //                   ep.Category_ID,
        //                   ep.Category_Name,
        //                   r.Skill_ID,
        //                   r.Skill_Name

        //               };
        //    var data1 = from r in dbobj.Tbl_Skills
        //                join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
        //                select new
        //                {
        //                    ep.Category_ID,
        //                    ep.Category_Name,
        //                    r.Skill_ID,
        //                    r.Skill_Name

        //                };
        //    return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        //}
        public JsonResult GetSkills(string sord, int page, int rows)
        {
            string categoryid = catid;
            string sk_id = skillid;
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;

            var Results = from ep in dbobj.Tbl_Category
                          join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID

                          select new
                          {
                              r.Skill_ID,
                              r.Skill_Name,
                              ep.Category_ID,
                              ep.Category_Name
                          };

            //if (((!string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id))) || ((string.IsNullOrEmpty(categoryid)) && (!string.IsNullOrEmpty(sk_id))))
            //{
            //    Results = from ep in dbobj.Tbl_Category
            //              join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
            //              where ep.Category_ID == catid || r.Skill_ID == sk_id
            //              select new
            //                {
            //                    r.Skill_ID,
            //                    r.Skill_Name,
            //                    ep.Category_Name
            //                };
            //}
            // else 
            if ((!string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id)))
            {
                Results = from ep in dbobj.Tbl_Category
                          join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
                          where ep.Category_ID == catid
                          select new
                          {
                              r.Skill_ID,
                              r.Skill_Name,
                              ep.Category_ID,
                              ep.Category_Name
                          };
            }
            else if ((!string.IsNullOrEmpty(categoryid)) && (!string.IsNullOrEmpty(sk_id)))
            {
                Results = from ep in dbobj.Tbl_Category
                          join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
                          where ep.Category_ID == catid && r.Skill_ID == sk_id
                          select new
                          {
                              r.Skill_ID,
                              r.Skill_Name,
                              ep.Category_ID,
                              ep.Category_Name
                          };
            }
            //else{

            //     Results = from ep in dbobj.Tbl_Category
            //                  join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID

            //                  select new
            //                    {
            //                        r.Skill_ID,
            //                        r.Skill_Name,
            //                        ep.Category_Name
            //                    };
            //  }
            //if (!string.IsNullOrEmpty(Category_Name))
            //{
            //    Results = Results.Where(x => x.Category_Name.Contains(Category_Name));
            //}
            //if (!string.IsNullOrEmpty(Skill_Name))
            //{
            //    Results = Results.Where(x => x.Skill_Name.Contains(Skill_Name));
            //}

            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Skill_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Skill_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [SessionOut]
    //    [ValidateAntiForgeryToken]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public string CreateSkills(Tbl_Skills obj)
        {
            obj.Category_ID = catid;
            
            var idValue = "";
            //int count = 0;
            ////var res = dbobj.Tbl_Skills.Select(x => x.Skill_Name).ToList();
            ////foreach(var i in res)
            ////{
            ////    if(i==obj.Skill_Name)
            ////    {
            ////        count = count + 1;
            ////        obj.Skill_Name = null;
            ////    }
            ////}
            var results = dbobj.Tbl_Skills.Select(x => x.Skill_ID).ToList();
            foreach (var i in results)
            {
                idValue = i;
            }
            var skill_Id = Convert.ToInt32(idValue) + 1;
            obj.Skill_ID = Convert.ToString(skill_Id);
            var duplicate = dbobj.Tbl_Skills.Select(x => x).ToList();
            int cnt = 0;
            foreach (var i in duplicate)
            {
                if ((((Convert.ToString(i.Skill_Name)).ToUpper() == obj.Skill_Name))||(((Convert.ToString(i.Skill_Name)).ToLower() == obj.Skill_Name)))
                    cnt = cnt + 1;
            }

            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    if (cnt == 0)
                    {
                        dbobj.Tbl_Skills.Add(obj);
                        dbobj.SaveChanges();
                        msg = "Saved Successfully";
                    }
                    else
                    {
                        msg = "Your given data is already exists";
                    }
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured: Please Select Category Dropdown";
            }
            return msg;
        }
        

        public string EditSkills(Tbl_Skills obj)
        {
            string msg;
            var Results = from ep in dbobj.Tbl_Category
                          join r in dbobj.Tbl_Skills on ep.Category_ID equals r.Category_ID
                          select new
                          {
                              r.Skill_ID,
                              r.Skill_Name,
                              ep.Category_Name,
                              r.Category_ID
                          };

            // var m = "";
            var n = "";
            // var result = dbobj.Tbl_Skills.Select(x => x).ToList();
            foreach (var i in Results)
            {
                if (i.Skill_ID == obj.Skill_ID)
                {
                    //  m = i.Skill_ID;
                    n = i.Category_ID;
                }
            }
            // obj.Skill_ID = m;
            obj.Category_ID = n;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteSkills(string id)
        {
            Tbl_Skills list = dbobj.Tbl_Skills.Find(id);
            dbobj.Tbl_Skills.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }


        //-------------------ViewScore---------------
        public ActionResult ViewScoreDescription()
        {
            Tbl_Category obj1 = new Tbl_Category();

            return View();
        }

        public JsonResult GetScoreDescription(string sord, int page, int rows)
        {

            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = dbobj.Tbl_Score_Description.Select(
                a => new
                {
                    a.Score_ID,
                    a.Score_Description,


                });


            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Score_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Score_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [SessionOut]
   //     [ValidateAntiForgeryToken]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public string CreateScoreDescription(Tbl_Score_Description obj)
        {
            int idValue = 0;

            var results = dbobj.Tbl_Score_Description.Select(x => x.Score_ID).ToList();
            foreach (var i in results)
            {
                idValue = i;
            }
            int score_Id = idValue + 1;
            obj.Score_ID = Convert.ToByte(score_Id);
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Score_Description.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditScoreDescription(Tbl_Score_Description obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteScoreDescription(byte? id)
        {
            Tbl_Score_Description list = dbobj.Tbl_Score_Description.Find(id);
            dbobj.Tbl_Score_Description.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }
        //----------------------ViewEmployeeDetails

        public ActionResult ViewEmployeeScores()
        {

            EmployeeScore model = new EmployeeScore();
            foreach (var Category in dbobj.Tbl_Category)
            {
                model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
            }
            foreach (var score in dbobj.Tbl_Score_Description)
            {
                model.Tbl_Score_Description.Add(new SelectListItem { Text = score.Score_Description, Value = Convert.ToString(score.Score_ID) });
            }

            return View(model);
        }

        [HttpPost]
        [SessionOut]
      //  [ValidateAntiForgeryToken]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult ViewEmployeeScores(string Category_ID, string Skill_ID, string EmpId, byte? Score_ID)
        {
            catid = Category_ID;
            skillid = Skill_ID;
            // if (Score_ID)
            scoreid = Score_ID;
            Empid = EmpId;
            EmployeeScore model = new EmployeeScore();
            {


                foreach (var Category in dbobj.Tbl_Category)
                {
                    model.Tbl_Category.Add(new SelectListItem { Text = Category.Category_Name, Value = Category.Category_ID });
                }

                if (Category_ID != "")
                {
                    var Skills = (from Skill in dbobj.Tbl_Skills
                                  where Skill.Category_ID == Category_ID
                                  select Skill).ToList();
                    foreach (var Skill in Skills)
                    {
                        model.Tbl_Skills.Add(new SelectListItem { Text = Skill.Skill_Name, Value = Skill.Skill_ID });
                    }


                }
                foreach (var score in dbobj.Tbl_Score_Description)
                {
                    model.Tbl_Score_Description.Add(new SelectListItem { Text = score.Score_Description, Value = Convert.ToString(score.Score_ID) });
                }

                return View(model);
            }
        }


        public JsonResult GetEmployeeScores(string sord, int page, int rows)
        {
            List<ReportEmployeeScore> reportlst = new List<ReportEmployeeScore>();
            string categoryid = catid;
            string sk_id = skillid;
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = (from ep in dbobj.Tbl_Employee_Score
                           join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                           join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                           join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID



                           select new
                           {
                               ep.EmpID,
                               sc.EmployeeName,

                               sc.Designation,

                               sc.ReportingPerson,

                               c.Category_Name,
                               m.Skill_Name,
                               ep.Score_Rating
                           });
            if ((string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id)) && (string.IsNullOrEmpty(Empid)) && scoreid == null)
            {
                Results = (from ep in dbobj.Tbl_Employee_Score
                           join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                           join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                           join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID



                           select new
                           {
                               ep.EmpID,
                               sc.EmployeeName,

                               sc.Designation,

                               sc.ReportingPerson,

                               c.Category_Name,
                               m.Skill_Name,
                               ep.Score_Rating
                           });
            }
            else
            {
                if (Empid == "")
                {


                    if ((!string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id)))
                    {
                        if (scoreid != null)
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       join sr in dbobj.Tbl_Score_Description on ep.Score_Rating equals sr.Score_ID
                                       where c.Category_ID == catid && sr.Score_ID == scoreid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                        else
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       where c.Category_ID == catid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }

                    }
                    else if ((!string.IsNullOrEmpty(categoryid)) && (!string.IsNullOrEmpty(sk_id)))
                    {
                        if (scoreid != null)
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       join sr in dbobj.Tbl_Score_Description on ep.Score_Rating equals sr.Score_ID
                                       where c.Category_ID == catid && m.Skill_ID == sk_id && sr.Score_ID == scoreid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                        else
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       where c.Category_ID == catid && m.Skill_ID == sk_id

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                    }
                    else if ((string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id)))
                    {
                        if (scoreid != null)
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       join sr in dbobj.Tbl_Score_Description on ep.Score_Rating equals sr.Score_ID
                                       where sr.Score_ID == scoreid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                        else
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       where c.Category_ID == catid && m.Skill_ID == sk_id

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                    }
                }
                //
                else
                {
                    if ((!string.IsNullOrEmpty(categoryid)) && (string.IsNullOrEmpty(sk_id)))
                    {

                        if (scoreid != null)
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       join sr in dbobj.Tbl_Score_Description on ep.Score_Rating equals sr.Score_ID
                                       where c.Category_ID == catid && sr.Score_ID == scoreid && ep.EmpID == Empid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                        else
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       where c.Category_ID == catid && ep.EmpID == Empid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                    }
                    else if ((!string.IsNullOrEmpty(categoryid)) && (!string.IsNullOrEmpty(sk_id)))
                    {
                        if (scoreid != null)
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       join sr in dbobj.Tbl_Score_Description on ep.Score_Rating equals sr.Score_ID
                                       where c.Category_ID == catid && m.Skill_ID == sk_id && sr.Score_ID == scoreid && ep.EmpID == Empid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                        else
                        {
                            Results = (from ep in dbobj.Tbl_Employee_Score
                                       join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                       join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                       join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                       where c.Category_ID == catid && m.Skill_ID == sk_id && ep.EmpID == Empid

                                       select new
                                       {
                                           ep.EmpID,
                                           sc.EmployeeName,

                                           sc.Designation,

                                           sc.ReportingPerson,

                                           c.Category_Name,
                                           m.Skill_Name,
                                           ep.Score_Rating
                                       });
                        }
                    }
                    else
                    {
                        Results = (from ep in dbobj.Tbl_Employee_Score
                                   join sc in dbobj.Tbl_EmployeeMaster on ep.EmpID equals sc.EmpID
                                   join c in dbobj.Tbl_Category on ep.Category_Name equals c.Category_ID

                                   join m in dbobj.Tbl_Skills on ep.Skill_Name equals m.Skill_ID

                                   where ep.EmpID == Empid

                                   select new
                                   {
                                       ep.EmpID,
                                       sc.EmployeeName,

                                       sc.Designation,

                                       sc.ReportingPerson,

                                       c.Category_Name,
                                       m.Skill_Name,
                                       ep.Score_Rating
                                   });
                    }
                }
            }
            foreach (var data in Results)
            {
                ReportEmployeeScore reportmodel = new ReportEmployeeScore();
                reportmodel.EmpID = data.EmpID;
                reportmodel.EmployeeName = data.EmployeeName;
                reportmodel.Designation = data.Designation;
                reportmodel.ReportingPerson = data.ReportingPerson;
                reportmodel.Category_Name = data.Category_Name;
                reportmodel.Skill_Name = data.Skill_Name;
                reportmodel.Score_Rating = data.Score_Rating;

                reportlst.Add(reportmodel);
            }


            reportobj = reportlst;
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        [SessionOut]
    //    [ValidateAntiForgeryToken]
        [CustomAuthorizeFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public string CreateEmployeeScores(Tbl_Employee_Score obj)
        {

            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Employee_Score.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditEmployeeScores(Tbl_Employee_Score obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteEmployeeScores(int Empid)
        {
            Tbl_Employee_Score list = dbobj.Tbl_Employee_Score.Find(Empid);
            dbobj.Tbl_Employee_Score.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }

        public void ExportToExcel()
        {
            var grid = new GridView();
            ReportEmployeeScore model = new ReportEmployeeScore();


            model.reportobj = reportobj;


            grid.DataSource = from data in model.reportobj
                              select new
                              {
                                  data.EmpID,
                                  data.EmployeeName,

                                  data.Designation,

                                  data.ReportingPerson,

                                  data.Category_Name,
                                  data.Skill_Name,
                                  data.Score_Rating


                              };
            grid.DataBind();
            Response.ClearContent();
            Response.AddHeader("content-dispotation", "attachment;filename=ExportedClientList.xls");
            Response.ContentType = "application/excel";
            StringWriter obj = new StringWriter();
            HtmlTextWriter htmlTextWriter = new HtmlTextWriter(obj);
            grid.RenderControl(htmlTextWriter);
            Response.Write(obj.ToString());
            Response.End();


        }





    }
}


