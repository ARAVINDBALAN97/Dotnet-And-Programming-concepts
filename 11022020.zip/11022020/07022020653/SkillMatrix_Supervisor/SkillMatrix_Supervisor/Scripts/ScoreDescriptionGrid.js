


$(document).ready(function () {
    $("#gridScore").jqGrid
    ({

        url: "/Admin/GetScoreDescription",
        datatype: 'json',
        mtype: 'Get',
        //table�header�name���
        colNames: ['Score_ID','Score_ID', 'Score_Description'],
        //colModel�takes�the�data�from�controller�and�binds�to�grid���
        colModel: [
               {
                   key: true,
                   hidden: false,
                   name: 'Score_ID',
                   index: 'Score_ID',
                   editable: false
               },
        {
           key: true,
            hidden: true,
            name: 'Score_ID',
            index: 'Score_ID',
            editable: true
        }, {
            key: false,
            name: 'Score_Description',
            index: 'Score_Description',
            editable: true
        }],

        pager: jQuery('#pagerScore'),
        rowNum: 10,
        rowList: [10, 20, 30, 40],
        height: '100%',
        viewrecords: true,
        caption: 'Score Description',
        emptyrecords: 'No�records�to�display',
        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
        multiselect: false
        //pager-you�have�to�choose�here�what�icons�should�appear�at�the�bottom��
        //like�edit,create,delete�icons��
    }).navGrid('#pagerScore',
    {
        edit: true,
        add: false,
        del: true,
        search: false,
        refresh: true
    }, {
        //�edit�options��
        zIndex: 100,
        url: '/Admin/EditScoreDescription',
        closeOnEscape: true,
        closeAfterEdit: true,
        recreateForm: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�add�options��
        zIndex: 100,
        url: "/Admin/CreateScoreDescription",
        closeOnEscape: true,
        closeAfterAdd: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        //�delete�options��
        zIndex: 100,
        url: "/Admin/DeleteScoreDescription",
        closeOnEscape: true,
        closeAfterDelete: true,
        recreateForm: true,
        msg: "Are�you�sure�you�want�to�delete�this�task?",
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }

    })
});






