﻿
       $(document).ready(function () {
           $.ajax({
               type: "GET",
               url: "/Employee_Supervisor/GetData",
               data: "{}",
               success: function (data) {
                   var s = '<option value="-1">Please Select a Employeename</option>';
                   for (var i = 0; i < data.length; i++) {
                       s += '<option value="' + data[i].EmpID + '">' + data[i].EmployeeName + '</option>';
                   }
                   $("#departmentsDropdown").html(s);
               }
           });
       });

function getValue() {
    var myVal = $("#departmentsDropdown").val();
    $("#show").val(myVal);
}
