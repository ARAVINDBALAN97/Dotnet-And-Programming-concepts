﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjectInitializer
{
    class Program
    {
        static void Main(string[] args)
        {
            ObjectInitializerExample oie = new ObjectInitializerExample()
            {
                Id = 3349,
                EmployeeName = "Barani Kumar",
                Gender = "Male",
                Position = "Java Developer"

            };

            Console.WriteLine("Id of an Employee : {0} ", oie.Id);
            Console.WriteLine("Name of Employee : {0}", oie.EmployeeName);
            Console.WriteLine("Gender  : {0}", oie.Gender);
            Console.WriteLine("Position in Organisation : {0}", oie.Position);

            Console.ReadLine();


        }
    }
}
