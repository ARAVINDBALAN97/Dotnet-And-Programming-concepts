﻿using System;                       
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ExtensionMethods
{
  public  class Program
    {
        static void Main(string[] args)
        {
            int Number;
            Console.WriteLine("Enter the Number To Check Even Or Odd:");
            Number = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine(Number.checkOddEven());


            string Email;
            Console.WriteLine("Enter Ur Mail :");
            Email = Console.ReadLine();
            Console.WriteLine(Email.IsEmailValid());

            Console.ReadLine();


        }
    }
}
