﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethods
{
    public static class IntExtension
    {
        public static string checkOddEven(this int i)
        {
            if (i % 2 == 0)
            {
                return "Number is Even";
            }
            else
            {
                return "Number is Odd";
            }
        }
    }
}
