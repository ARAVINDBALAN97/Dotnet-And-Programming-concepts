﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;


namespace ExtensionMethods
{
  public static  class EmailValidation
    {
      public static string IsEmailValid(this string input)
      {
          string valid = @"^\w[a-z0-9]+@\w[a-z0-9]+\.+[a-zA-Z]{2,4}$"; 

          Regex regex = new Regex(valid);

          if (regex.IsMatch(input))
          {
              return "Your Maildid is Valid";
          }
          else 
          {
              return "Your MailId is Invalid";
          }
      }
    }
}
