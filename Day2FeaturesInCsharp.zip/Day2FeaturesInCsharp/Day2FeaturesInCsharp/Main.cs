﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2FeaturesInCsharp
{
    class Program
    {
        static void Main(string[] args)
        {
            AutoImplementedProperties aip = new AutoImplementedProperties();


            aip.Id = 3370;
            aip.EmployeeName = "Aravind";
            aip.Gender = "Gender";
            aip.Position = "Programmer Analyst Trainee";


            Console.WriteLine("Id of an Employee : {0} ",aip.Id);
            Console.WriteLine("Name of Employee : {0}",aip.EmployeeName);
            Console.WriteLine("Gender  : {0}",aip.Gender);
            Console.WriteLine("Position in Organisation : {0}",aip.Position);

            Console.ReadLine();

        }
    }
}
