﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2FeaturesInCsharp
{
  public   class AutoImplementedProperties
    {
      public int Id { get; set; }
      public string EmployeeName { get; set; }
      public string Gender { get; set; }
      public string Position { get; set; }
     
    }
}
