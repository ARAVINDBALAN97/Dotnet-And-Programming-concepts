﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using simplegrid.Models;
using System.Data.Entity;

namespace simplegrid.Controllers

{
    public class SampleController : Controller
    {
        //
        // GET: /Sample/
        public ActionResult Index()
        {
            return View();
        }
        Aravind_traineeEntities1 obj = new Aravind_traineeEntities1();

        public JsonResult GetValues(string sidx, string sord, int page, int rows) //Gets the todo Lists.  
            {  
                int pageIndex = Convert.ToInt32(page) - 1;  
                int pageSize = rows;  
                var Results = obj.Tbl_Employees.Select(  
                    a => new  
                    {  
                        a.EmpId,  
                            a.EmpName,  
                            a.EmpGender,  
                            a.EmoDob, 
                    });  
                int totalRecords = Results.Count();  
                var totalPages = (int) Math.Ceiling((float) totalRecords / (float) rows);  
                if (sord.ToUpper() == "DESC")  
                {  
                    Results = Results.OrderByDescending(s => s.EmpId);  
                    Results = Results.Skip(pageIndex * pageSize).Take(pageSize);  
                } else  
                {  
                    Results = Results.OrderBy(s => s.EmpId);  
                    Results = Results.Skip(pageIndex * pageSize).Take(pageSize);  
                }  
                var jsonData = new  
                {  
                    total = totalPages,  
                        page,  
                        records = totalRecords,  
                        rows = Results  
                };  
                return Json(jsonData, JsonRequestBehavior.AllowGet);  
            }  
  
        // TODO:insert a new row to the grid logic here  
        [HttpPost]  
        public string Create( Tbl_Employees obj1)  
        {  
            string msg;  
            try  
            {  
                if (ModelState.IsValid)  
                {  
                    obj.Tbl_Employees.Add(obj1);
                    obj.SaveChanges();  
                    msg = "Saved Successfully";  
                } else  
                {  
                    msg = "Validation data not successfull";  
                }  
            } catch (Exception ex)  
            {  
                msg = "Error occured:" + ex.Message;  
            }  
            return msg;  
        } 
 
        public string Edit(Tbl_Employees obj1)  
        {  
            string msg;  
            try  
            {  
                if (ModelState.IsValid)  
                {  
                    obj.Entry(obj1).State = EntityState.Modified;  
                    obj.SaveChanges();  
                    msg = "Saved Successfully";  
                } else  
                {  
                    msg = "Validation data not successfull";  
                }  
            } catch (Exception ex)  
            {  
                msg = "Error occured:" + ex.Message;  
            }  
            return msg;  
        }  
        public string Delete(int EmpId)  
        {  
            Tbl_Employees list = obj.Tbl_Employees.Find(EmpId);  
            obj.Tbl_Employees.Remove(list);  
            obj.SaveChanges();  
            return "Deleted successfully";  
        }  
    }  
}  
//Using GetValues Json method we are binding the db data to the jqgrid in the format of Json (javascript object notation).

//Here parameters sidx means serial index; sort variable for sorting order; page numbers is for pages; and row parameter takes the numbers rows in jqgrid.

//Finally we are binding data using json() method as a json object.
//Step 6: Create script for Jqgrid

//The javascript code format for jqgrid is as follows,
//Create myjqgrid.js

