﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(simplegrid.Startup))]
namespace simplegrid
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
