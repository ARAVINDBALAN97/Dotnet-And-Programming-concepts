﻿$(document).ready(function () {
    $("#grid").jqGrid
    ({
        url: "/Sample/GetValues",
        datatype: 'json',
        mtype: 'Get',
        //table header name   
        colNames: ['EmpId', 'EmpName', 'EmpGender', 'EmoDob'],
        //colModel takes the data from controller and binds to grid   
        colModel: [
        {
            key: true,
            hidden: false,
            name: 'EmpId',
            index: 'EmpId',
            editable: true
        }, {
            key: false,
            name: 'EmpName',
            index: 'EmpName',
            editable: true
        }, {
            key: false,
            name: 'EmpGender',
            index: 'EmpGender',
            editable: true
        }, {
            key: false,
            name: 'EmoDob',
            index: 'EmoDob',
            editable: true,        }],

        pager: jQuery('#pager'),
        rowNum: 10,
        rowList: [10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
        height: '100%',
        viewrecords: true,
        caption: 'Jq grid sample Application',
        emptyrecords: 'No records to display',
        jsonReader:
        {
            root: "rows",
            page: "page",
            total: "total",
            records: "records",
            repeatitems: false,
            Id: "0"
        },
        autowidth: true,
        multiselect: false
        //pager-you have to choose here what icons should appear at the bottom  
        //like edit,create,delete icons  
    }).navGrid('#pager',
    {
        edit: true,
        add: true,
        del: true,
        search: true,
        refresh: true
    }, {
        // edit options  
        zIndex: 100,
        url: '/Sample/Edit',
        closeOnEscape: true,
        closeAfterEdit: true,
        recreateForm: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        // add options  
        zIndex: 100,
        url: "/Sample/Create",
        closeOnEscape: true,
        closeAfterAdd: true,
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }
    }, {
        // delete options  
        zIndex: 100,
        url: "/Sample/Delete",
        closeOnEscape: true,
        closeAfterDelete: true,
        recreateForm: true,
        msg: "Are you sure you want to delete this task?",
        afterComplete: function (response) {
            if (response.responseText) {
                alert(response.responseText);
            }
        }

    });
});
