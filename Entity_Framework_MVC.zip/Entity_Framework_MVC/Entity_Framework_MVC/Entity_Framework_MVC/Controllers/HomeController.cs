﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Entity_Framework_MVC.Controllers
{
public class HomeController : Controller
{
    // GET: Home
    public ActionResult Index()
    {
        NorthwindEntities entities = new NorthwindEntities();
            var q = from customer in entities.Customers.Take(10)
                    select customer;
        return View(q);
    }
}
}