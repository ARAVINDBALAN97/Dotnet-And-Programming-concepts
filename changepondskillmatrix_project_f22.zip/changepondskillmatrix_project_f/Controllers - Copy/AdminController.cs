﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using changepondskillmatrix_project_f.Models;
using System.Data.Entity;

namespace changepondskillmatrix_project_f.Controllers
{
    public class AdminController : Controller
    {
        //
        // GET: /Admin/
        public ActionResult Adminhome()
        {
            return View();
        }

        public ActionResult ViewCategory()
        {
            return View();
        }

        Db_Ep_SkillMatrix_ProjectEntities dbobj = new Db_Ep_SkillMatrix_ProjectEntities();
        
       public JsonResult GetCategory(string sord,int page,int rows)  
        {
               
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = dbobj.Tbl_Category.Select(
                a => new
                {
                    a.Category_ID,
                    a.Category_Name,
                   
                    
                });
                
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Category_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Category_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page=page,
                records = totalRecords,
                rows = Results
            };
            return  Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public string CreateCategory(Tbl_Category obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Category.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditCategory(Tbl_Category obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteCategory(int Empid)
        {
            Tbl_Category list = dbobj.Tbl_Category.Find(Empid);
            dbobj.Tbl_Category.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }

//---------------------------------viewskills


        public ActionResult ViewSkills()
        {
            return View();
        }

        public JsonResult GetSkills(string sord, int page, int rows)
        {

            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = dbobj.Tbl_Skills.Select(
                a => new
                {
                    a.Skill_ID,
                    a.Skill_Name,
                    a.Category_ID,

                });

            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Skill_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Skill_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public string CreateSkills(Tbl_Skills obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Skills.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditSkills(Tbl_Skills obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteSkills(int Empid)
        {
            Tbl_Skills list = dbobj.Tbl_Skills.Find(Empid);
            dbobj.Tbl_Skills.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }


//-------------------ViewScore---------------
        public ActionResult ViewScoreDescription()
        {
            return View();
        }
        public JsonResult GetScoreDescription(string sord, int page, int rows)
        {

            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            var Results = dbobj.Tbl_Score_Description.Select(
                a => new
                {
                    a.Score_ID,
                    a.Score_Description,


                });

            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.Score_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.Score_ID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public string CreateScoreDescription(Tbl_Score_Description obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Score_Description.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditScoreDescription(Tbl_Score_Description obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteScoreDescription(int Empid)
        {
            Tbl_Score_Description list = dbobj.Tbl_Score_Description.Find(Empid);
            dbobj.Tbl_Score_Description.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }
        //----------------------ViewEmployeeDetails


        public ActionResult ViewEmployeeScores()
        {
            return View();
        }
        public JsonResult GetEmployeeScores(string sord, int page, int rows)
        {

            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;
            //var Results = dbobj.Tbl_Employee_Score.Select(
            //    a => new
            //    {
            //        a.EmpID,
            //        a.Category_Name,
            //        a.Skill_Name,
            //        a.Score_Rating,

            //    });
            var Results = (from ep in dbobj.Tbl_EmployeeMaster
                           join r in dbobj.Tbl_Role on ep.Role equals r.RoleID
                           join sc in dbobj.Tbl_Employee_Score on ep.EmpID equals sc.EmpID


                           select new
                           {
                               ep.EmpID,
                               ep.EmployeeName,
                               ep.DOJ,
                               ep.Designation,
                               ep.MailID,
                               ep.ReportingPerson,
                               r.Role,
                               sc.Score_Rating
                           });
          
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            var jdata = new
            {
                total = totalPages,
                page = page,
                records = totalRecords,
                rows = Results
            };
            return Json(jdata, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public string CreateEmployeeScores(Tbl_Employee_Score obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Tbl_Employee_Score.Add(obj);
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }

        public string EditEmployeeScores(Tbl_Employee_Score obj)
        {
            string msg;
            try
            {
                if (ModelState.IsValid)
                {
                    dbobj.Entry(obj).State = EntityState.Modified;
                    dbobj.SaveChanges();
                    msg = "Saved Successfully";
                }
                else
                {
                    msg = "Validation data not successfull";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        public string DeleteEmployeeScores(int Empid)
        {
            Tbl_Employee_Score list = dbobj.Tbl_Employee_Score.Find(Empid);
            dbobj.Tbl_Employee_Score.Remove(list);
            dbobj.SaveChanges();
            return "Deleted successfully";
        }
    }  
}  

	
