﻿$(function () {
    if ($("#Skill_ID option").length > 1)  {
        $("#Skill_ID").removeAttr("disabled");
    }
    if ($("#Score_ID option").length > 1) {
        $("#Score_ID").removeAttr("disabled");
    }



    if ($("#Category_ID").val() != "" && $("#Skill_ID").val() != "" && $("Score_ID").val() !="") {
        var message = "Category: " + $("#Category_ID option:selected").text();
        message += "\nSkill: " + $("#Skill_ID option:selected").text();
        message += "\nScore: " + $("#nScore_ID option:selected").text();
        alert(message);
    }
});