﻿$(document).ready(function () {
    $.ajax({
        type: "GET",
        url: "/Employee_Supervisor/Get",
        data: "{}",
        success: function (data) {
            var s = '<option value="-1">Please Select a Employeename</option>';
            for (var i = 0; i < data.length; i++) {
                s += '<option value="' + data[i].EmpID + '">' + data[i].EmployeeName + '</option>';

            }
            $("#EmpNameDropdown").html(s);
        }
    });
});

function getValue() {
    var myVal = $("#EmpNameDropdown").val();
    $("#show").val(myVal);
}