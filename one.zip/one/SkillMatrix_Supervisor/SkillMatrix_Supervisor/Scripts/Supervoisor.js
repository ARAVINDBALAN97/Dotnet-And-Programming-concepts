﻿$(document).ready(function () {
    $.ajax({
        type: "GET",
        url: "/Employee_Supervisor/getEmployees",
        data: "{}",
        success: function (Data) {
            var s = '<option value="-1">Please Select a Employeename</option>';
            for (var i = 0; i < Data.length; i++) {
                s += '<option value="' + Data[i].EmpID + '">' + Data[i].EmployeeName + '</option>';

            }
            $("#EmpNameDropdown").html(s);
        }
    });
});

function getValue() {
    var myVal = $("#EmpNameDropdown").val();
    $("#show").val(myVal);
}