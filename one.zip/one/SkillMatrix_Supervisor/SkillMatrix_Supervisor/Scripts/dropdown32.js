﻿$(document).ready(function () {
    $.ajax({
        type: "GET",
        url: "/Employee_Supervisor/getEmployees",
        data: "{}",
        success: function (jsonData) {
            var s = '<option value="-1">Please Select a Employeename</option>';
            for (var i = 0; i < jsonData.length; i++) {
                s += '<option value="' + jsonData[i].EmpID + '">' + jsonData[i].EmployeeName + '</option>';

            }
            $("#EmpNameDropdown").html(s);
        }
    });
});

function getValue() {
    var myVal = $("#EmpNameDropdown").val();
    $("#show").val(myVal);
}