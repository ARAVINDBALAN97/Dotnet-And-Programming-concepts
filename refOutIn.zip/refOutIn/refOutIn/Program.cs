﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace refOutIn
{
    public class a
    {
        void func(ref int a, out int b, int c)
        {
            b = a * 10;
            c = c + 10;
            a = a + 10;
        }
        static void Main(string[] args)
        {
            int x, y, z;
            Console.WriteLine("Enter the first number");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the SECOND number");
            z = Convert.ToInt32(Console.ReadLine());
            a a1 = new a();
            a1.func(ref x, out y, z);
            Console.WriteLine(x);
            Console.WriteLine(y);
            Console.WriteLine(z);

            Console.Read();
        }
       
    }
}
