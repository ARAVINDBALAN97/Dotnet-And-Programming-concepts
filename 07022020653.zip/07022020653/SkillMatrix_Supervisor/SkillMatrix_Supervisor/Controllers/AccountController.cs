﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Web.Security;

namespace SkillMatrix_Supervisor.Controllers
{
    public class AccountController : Controller
    {
        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();
        
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Tbl_Userlogin user)
        {
            var count = db.Tbl_Userlogin.Where(u => u.UserName == user.UserName && u.password == user.password).Count();

            var role = (from usertbl in db.Tbl_Userlogin
                        where usertbl.UserName == user.UserName
                        select usertbl.Role).FirstOrDefault();

            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(user.UserName, false);

                if (role == 1)
                {
                    Session["UserName"] = user.UserName;
                    return RedirectToAction("Adminhome", "Admin");

                }
                else if ( role == 2)
                {
                    Session["UserName"] = user.UserName;
                    return RedirectToAction("Index", "Supervisor");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }
            else
            {
                TempData["message"] = "U r not Authorized to this page";

                return View();
            }

        }
        public ActionResult Logout()
        {

            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();

            FormsAuthentication.SignOut();

            this.Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1));
            this.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Response.Cache.SetNoStore(); 

            return RedirectToAction("Index", "Home");
        }

        //public ActionResult Manage()
        //{

        //}
	}
}