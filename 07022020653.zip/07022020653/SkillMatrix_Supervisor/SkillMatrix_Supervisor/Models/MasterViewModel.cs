﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SkillMatrix_Supervisor.Models
{
    public class MasterViewModel
    {
        public MasterViewModel()
        {
            this.Tbl_Category = new List<SelectListItem>();
            this.Tbl_Skills = new List<SelectListItem>();
            this.Tbl_Score_Description = new List<SelectListItem>();
            this.Tbl_EmployeeMaster = new List<SelectListItem>();
        }
        public List<SelectListItem> Tbl_EmployeeMaster { get; set; }
        public List<SelectListItem> Tbl_Category { get; set; }
        public List<SelectListItem> Tbl_Skills { get; set; }
        public List<SelectListItem> Tbl_Score_Description { get; set; }

        [Display(Name = "Employee Wise")]
        public string EmpID { get; set; }
         [Display(Name = "Employee Wise")]
        public string EmployeeName { get; set; }


        public string Category_ID { get; set; }
        //public string Category_Name { get; set; }
        public string Skill_ID { get; set; }
         [Display(Name = "CategoryName")]
        public string Category_Name { get; set; }
         [Display(Name = "SkillName")]
        public string Skill_Name { get; set; }
         [Display(Name = "ScoreDescription")]
        public int Score_Description { get; set; }
        public int Score_ID { get; set; }
    }
}