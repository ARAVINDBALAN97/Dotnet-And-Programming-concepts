﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CPSMproject.Models;
using System.Web.Routing;

namespace CPSMproject.Infrastructure
{
    public class CustomAuthorizeFilter : AuthorizeAttribute
    {
        private readonly string[] allowedroles;
         public CustomAuthorizeFilter (params string[] Roles )
                    {
            this.allowedroles = Roles;
        }

         protected override bool AuthorizeCore(HttpContextBase httpContext)
         {
             bool Authorize = false;
             var username = Convert.ToString(httpContext.Session["UserName"]);
                 if (!string.IsNullOrEmpty(username))
                 {
                     using (var context = new Db_Ep_SkillMatrix_ProjectEntities())
                     {
                         var userroles = (from usertbl in context.Tbl_Userlogin
                                          join roletbl
                                              in context.Tbl_Role on usertbl.Role equals roletbl.RoleID
                                          where usertbl.UserName == username
                                          select new
                                          {
                                              roletbl.Role
                                          }).FirstOrDefault();

                         foreach (var i in allowedroles)
                         {
                             if (i == userroles.Role)
                                 return true;
                         }

                        //if (allowedroles.Contains(userroles.))
                        //{
                        //    return true;
                        //}

                       
                     }
                 }

             return Authorize;
         }
         protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
         {
             filterContext.Result = new RedirectToRouteResult(
                   new RouteValueDictionary
                   {
                        {"Controller" , "Home" },
                        {"Action" , "Index"}
                   });
         }

    }

} 