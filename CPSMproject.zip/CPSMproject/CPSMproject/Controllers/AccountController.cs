﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using CPSMproject.Models;
using System.Web.Security;

namespace CPSMproject.Controllers
{
    [AllowAnonymous]
    public class AccountController : Controller
    {
        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();

        public ActionResult Login()
        {
            return View();
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login (Tbl_Userlogin User )
        {
            var count = db.Tbl_Userlogin.Where(u => u.UserName == User.UserName && u.password == User.password).Count();
            var role = (from usertbl in db.Tbl_Userlogin
                         where usertbl.UserName == User.UserName
                         select usertbl.Role).FirstOrDefault();

            
            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(User.UserName, false);
                if (role == 1)
                {
                    
                    Session["UserName"] = User.UserName;
                    return RedirectToAction("Index", "Supervisor");

                }
                else if (role == 2)
                {
                    Session["UserName"] = User.UserName;
                    return RedirectToAction("Index", "Admin");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
               
            }
            else
            {
                TempData["message"] = "U r not Authorized to this page";

                return View();
            }
            
        }


        public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }


	}
}