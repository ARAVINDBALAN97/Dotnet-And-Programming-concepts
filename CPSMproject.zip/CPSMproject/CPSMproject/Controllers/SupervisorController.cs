﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CPSMproject.Models;
using CPSMproject.Infrastructure;

namespace CPSMproject.Controllers
{
    [CustomAuthenticationFilter]
    [CustomAuthorizeFilter(Roles: "Admin")]
    [Authorize(Roles="Admin")]
    
    public class SupervisorController : Controller
    {
        private Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();

        // GET: /Supervisor/
        public ActionResult Index()
        {
            var tbl_employee_score = db.Tbl_Employee_Score.Include(t => t.Tbl_Category).Include(t => t.Tbl_EmployeeMaster).Include(t => t.Tbl_Score_Description).Include(t => t.Tbl_Skills);
            return View(tbl_employee_score.ToList());
        }

        // GET: /Supervisor/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_Employee_Score tbl_employee_score = db.Tbl_Employee_Score.Find(id);
            if (tbl_employee_score == null)
            {
                return HttpNotFound();
            }
            return View(tbl_employee_score);
        }

        // GET: /Supervisor/Create
        public ActionResult Create()
        {
            ViewBag.Category_Name = new SelectList(db.Tbl_Category, "Category_ID", "Category_Name");
            ViewBag.EmpID = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName");
            ViewBag.Score_Rating = new SelectList(db.Tbl_Score_Description, "Score_ID", "Score_Description");
            ViewBag.Skill_Name = new SelectList(db.Tbl_Skills, "Skill_ID", "Skill_Name");
            return View();
        }

        // POST: /Supervisor/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        [CustomAuthorizeFilter(Roles: "Admin")]
        public ActionResult Create([Bind(Include="SerialNumber,EmpID,Category_Name,Skill_Name,Score_Rating")] Tbl_Employee_Score tbl_employee_score)
        {
            if (ModelState.IsValid)
            {
                db.Tbl_Employee_Score.Add(tbl_employee_score);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Category_Name = new SelectList(db.Tbl_Category, "Category_ID", "Category_Name", tbl_employee_score.Category_Name);
            ViewBag.EmpID = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employee_score.EmpID);
            ViewBag.Score_Rating = new SelectList(db.Tbl_Score_Description, "Score_ID", "Score_Description", tbl_employee_score.Score_Rating);
            ViewBag.Skill_Name = new SelectList(db.Tbl_Skills, "Skill_ID", "Skill_Name", tbl_employee_score.Skill_Name);
            return View(tbl_employee_score);
        }

        // GET: /Supervisor/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_Employee_Score tbl_employee_score = db.Tbl_Employee_Score.Find(id);
            if (tbl_employee_score == null)
            {
                return HttpNotFound();
            }
            ViewBag.Category_Name = new SelectList(db.Tbl_Category, "Category_ID", "Category_Name", tbl_employee_score.Category_Name);
            ViewBag.EmpID = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employee_score.EmpID);
            ViewBag.Score_Rating = new SelectList(db.Tbl_Score_Description, "Score_ID", "Score_Description", tbl_employee_score.Score_Rating);
            ViewBag.Skill_Name = new SelectList(db.Tbl_Skills, "Skill_ID", "Skill_Name", tbl_employee_score.Skill_Name);
            return View(tbl_employee_score);
        }

        // POST: /Supervisor/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        [CustomAuthorizeFilter(Roles: "Admin")]
        public ActionResult Edit([Bind(Include="SerialNumber,EmpID,Category_Name,Skill_Name,Score_Rating")] Tbl_Employee_Score tbl_employee_score)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_employee_score).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Category_Name = new SelectList(db.Tbl_Category, "Category_ID", "Category_Name", tbl_employee_score.Category_Name);
            ViewBag.EmpID = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employee_score.EmpID);
            ViewBag.Score_Rating = new SelectList(db.Tbl_Score_Description, "Score_ID", "Score_Description", tbl_employee_score.Score_Rating);
            ViewBag.Skill_Name = new SelectList(db.Tbl_Skills, "Skill_ID", "Skill_Name", tbl_employee_score.Skill_Name);
            return View(tbl_employee_score);
        }

        // GET: /Supervisor/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_Employee_Score tbl_employee_score = db.Tbl_Employee_Score.Find(id);
            if (tbl_employee_score == null)
            {
                return HttpNotFound();
            }
            return View(tbl_employee_score);
        }

        // POST: /Supervisor/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        [CustomAuthorizeFilter(Roles: "Admin")]
        public ActionResult DeleteConfirmed(int id)
        {
            Tbl_Employee_Score tbl_employee_score = db.Tbl_Employee_Score.Find(id);
            db.Tbl_Employee_Score.Remove(tbl_employee_score);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
