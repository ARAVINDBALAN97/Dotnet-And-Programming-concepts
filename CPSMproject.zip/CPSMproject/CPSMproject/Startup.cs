﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(CPSMproject.Startup))]
namespace CPSMproject
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
