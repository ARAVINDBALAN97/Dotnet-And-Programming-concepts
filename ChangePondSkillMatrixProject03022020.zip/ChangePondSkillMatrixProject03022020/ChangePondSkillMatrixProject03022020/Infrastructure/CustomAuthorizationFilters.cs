﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ChangePondSkillMatrixProject03022020.Models;
using System.Web.Routing;

namespace ChangePondSkillMatrixProject03022020.Infrastructure
{
    public class CustomAuthorizationFilter : AuthorizeAttribute
    {
        private readonly string[] allowedroles;

        public CustomAuthorizationFilter(params string[] Roles)
        {
            this.allowedroles = Roles;
        }
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool authorize = false;
            var username = Convert.ToString(httpContext.Session["UserName"]);
            if (!string.IsNullOrEmpty(username))
            {
                using (var db = new Db_Ep_SkillMatrix_ProjectEntities())
                {
                    var userroles = (from logintble in db.Tbl_Userlogin
                                     join empmastertbl in db.Tbl_EmployeeMaster
                                         on logintble.UserName equals empmastertbl.UserName
                                     where logintble.UserName == empmastertbl.ReportingPerson
                                     select new
                                     {
                                         empmastertbl.EmpID,
                                         empmastertbl.UserName,
                                         empmastertbl.MailID,
                                         empmastertbl.Designation
                                     }).FirstOrDefault();

                    foreach (var item in allowedroles)
                    {
                        if (item == userroles.EmpID && item == userroles.UserName && item == userroles.MailID && item == userroles.Designation)
                            return true;
                    }
                }
            }
            return authorize;
        }
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectToRouteResult(
               new RouteValueDictionary  
               {  
                    { "Controller", "Home" },  
                    { "Action", "Index" }  
               });
        }
    }
}