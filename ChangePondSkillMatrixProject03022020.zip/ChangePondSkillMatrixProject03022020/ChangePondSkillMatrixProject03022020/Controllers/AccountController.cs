﻿using ChangePondSkillMatrixProject03022020.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace ChangePondSkillMatrixProject03022020.Controllers
{


    public class AccountController : Controller
    {
        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Tbl_Userlogin user)
        {
            var count = db.Tbl_Userlogin.Where(u => u.UserName == user.UserName && u.password == user.password).Count();

            if (count != 0)
            {
                FormsAuthentication.SetAuthCookie(user.UserName, false);
                FormsAuthentication.SetAuthCookie(user.Role.ToString(), false);
                if (user.Role == 1)
                {
                    Session["UserName"] = user.UserName;
                    return RedirectToAction("Index", "Admin");
                }
                else if (user.Role == 2)
                {
                    Session["UserName"] = user.UserName;
                    return RedirectToAction("Index", "Supervisor");
                }
                else
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            else
            {
                TempData["message"] = "U r not Authorized to this page";

                return View();
            }
        }
             public ActionResult Logout()
        {
            FormsAuthentication.SignOut();
            return RedirectToAction("Index", "Home");
        }
           
        }
    }
