﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ChangePondSkillMatrixProject03022020.Models;
using ChangePondSkillMatrixProject03022020.Infrastructure;
namespace ChangePondSkillMatrixProject03022020.Controllers
{
    //[CustomAuthenticationFilter]
    //[CustomAuthorizationFilter (Roles:"Admin")]
    [Authorize (Roles="Admin")]
    public class AdminController : Controller
    {
        private Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();

        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult Index()
        {
            var tbl_employeemaster = db.Tbl_EmployeeMaster.Include(t => t.Tbl_EmployeeMaster2).Include(t => t.Tbl_Role).Include(t => t.Tbl_Userlogin);
            return View(tbl_employeemaster.ToList());
        }

        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_EmployeeMaster tbl_employeemaster = db.Tbl_EmployeeMaster.Find(id);
            if (tbl_employeemaster == null)
            {
                return HttpNotFound();
            }
            return View(tbl_employeemaster);
        }

        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult Create()
        {
            ViewBag.ReportingPerson = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName");
            ViewBag.Role = new SelectList(db.Tbl_Role, "RoleID", "Role");
            ViewBag.UserName = new SelectList(db.Tbl_Userlogin, "UserName", "password");
            return View();
        }

        // POST: /Admin/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult Create([Bind(Include="EmpID,EmployeeName,DOJ,MailID,Designation,ReportingPerson,Role,UserName")] Tbl_EmployeeMaster tbl_employeemaster)
        {
            if (ModelState.IsValid)
            {
                db.Tbl_EmployeeMaster.Add(tbl_employeemaster);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.ReportingPerson = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employeemaster.ReportingPerson);
            ViewBag.Role = new SelectList(db.Tbl_Role, "RoleID", "Role", tbl_employeemaster.Role);
            ViewBag.UserName = new SelectList(db.Tbl_Userlogin, "UserName", "password", tbl_employeemaster.UserName);
            return View(tbl_employeemaster);
        }

          //[CustomAuthorizationFilter (Roles:"Admin")]
           [Authorize (Roles="Admin")]
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_EmployeeMaster tbl_employeemaster = db.Tbl_EmployeeMaster.Find(id);
            if (tbl_employeemaster == null)
            {
                return HttpNotFound();
            }
            ViewBag.ReportingPerson = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employeemaster.ReportingPerson);
            ViewBag.Role = new SelectList(db.Tbl_Role, "RoleID", "Role", tbl_employeemaster.Role);
            ViewBag.UserName = new SelectList(db.Tbl_Userlogin, "UserName", "password", tbl_employeemaster.UserName);
            return View(tbl_employeemaster);
        }

        // POST: /Admin/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
          //[CustomAuthorizationFilter(Roles: "Admin")]
          [Authorize(Roles = "Admin")]
        public ActionResult Edit([Bind(Include="EmpID,EmployeeName,DOJ,MailID,Designation,ReportingPerson,Role,UserName")] Tbl_EmployeeMaster tbl_employeemaster)
        {
            if (ModelState.IsValid)
            {
                db.Entry(tbl_employeemaster).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.ReportingPerson = new SelectList(db.Tbl_EmployeeMaster, "EmpID", "EmployeeName", tbl_employeemaster.ReportingPerson);
            ViewBag.Role = new SelectList(db.Tbl_Role, "RoleID", "Role", tbl_employeemaster.Role);
            ViewBag.UserName = new SelectList(db.Tbl_Userlogin, "UserName", "password", tbl_employeemaster.UserName);
            return View(tbl_employeemaster);
        }

        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Tbl_EmployeeMaster tbl_employeemaster = db.Tbl_EmployeeMaster.Find(id);
            if (tbl_employeemaster == null)
            {
                return HttpNotFound();
            }
            return View(tbl_employeemaster);
        }

        // POST: /Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        //[CustomAuthorizationFilter(Roles: "Admin")]
        [Authorize(Roles = "Admin")]
        public ActionResult DeleteConfirmed(string id)
        {
            Tbl_EmployeeMaster tbl_employeemaster = db.Tbl_EmployeeMaster.Find(id);
            db.Tbl_EmployeeMaster.Remove(tbl_employeemaster);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
