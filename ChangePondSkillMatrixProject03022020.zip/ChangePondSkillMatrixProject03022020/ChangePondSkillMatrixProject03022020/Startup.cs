﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(ChangePondSkillMatrixProject03022020.Startup))]
namespace ChangePondSkillMatrixProject03022020
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
