﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.Entity;
using JqgridCodeFirst.Models;



namespace JqgridCodeFirst.DBContext
{
    public class TodoListContext:DbContext
    {
        public DbSet<TodoList> TodoLists { get; set; }
    }
}