﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(JqgridCodeFirst.Startup))]
namespace JqgridCodeFirst
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
