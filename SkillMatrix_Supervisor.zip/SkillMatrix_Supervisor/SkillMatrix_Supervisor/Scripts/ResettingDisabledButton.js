﻿
$(document).ready(function () {

    $("#view").click(function () {


       
          //  $(".Dropdown").removeAttr("disabled");
       
        $("#category").removeAttr("disabled");
        $("#score").removeAttr("disabled");

    });

    $("#category").change(function () {
        $("#category").removeAttr("disabled");
    });

});
