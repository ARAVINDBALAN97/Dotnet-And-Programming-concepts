﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Web.Routing;
namespace SkillMatrix_Supervisor.Infrastructure
{
    public class CustomAuthorizeFilter : AuthorizeAttribute
    {
        private readonly string[] allowedroles;
        public CustomAuthorizeFilter(params string[] Roles)
        {
            this.allowedroles = Roles;
        }
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            bool Authorize = false;
            var username = Convert.ToString(httpContext.Session["UserName"]);
            if (!string.IsNullOrEmpty(username))
            {
                using (var context = new Db_Ep_SkillMatrix_ProjectEntities())
                {
                    var userroles = (from usertbl in context.Tbl_Userlogin
                                     join roletbl
                                         in context.Tbl_Role on usertbl.Role equals roletbl.RoleID
                                     where usertbl.UserName == username
                                     select new
                                     {
                                         roletbl.Role
                                     }).FirstOrDefault();

                    foreach (var i in allowedroles)
                    {
                        if (i == userroles.Role)
                            return true;
                    }
                }
               

            }
             return Authorize;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            HttpContext ctx = HttpContext.Current;
            // check if session is supported  
            if (ctx.Session != null)
            {
                // check if a new session id was generated  
                if (ctx.Session["UserName"] == null || ctx.Session.IsNewSession)
                {
                    //Check is Ajax request  
                    if (filterContext.HttpContext.Request.IsAjaxRequest())
                    {
                        filterContext.HttpContext.Response.ClearContent();
                        filterContext.HttpContext.Items["AjaxPermissionDenied"] = true;
                    }
                    // check if a new session id was generated  
                    else
                    {
                        filterContext.Result = new RedirectResult("~/Account/Login");
                    }
                }
            }
            base.HandleUnauthorizedRequest(filterContext);
        }  
        }
    }
