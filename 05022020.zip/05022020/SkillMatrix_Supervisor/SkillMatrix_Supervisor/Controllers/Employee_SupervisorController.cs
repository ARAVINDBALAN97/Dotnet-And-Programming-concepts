﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Data.Entity;
using System.Web.Script.Serialization;
namespace SkillMatrix_Supervisor.Controllers
{
    public class Employee_SupervisorController : Controller
    {


        Db_Ep_SkillMatrix_ProjectEntities db = new Db_Ep_SkillMatrix_ProjectEntities();

        //
        // GET: /Employee_Supervisor/
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetData()
        {
            var data = from employee in db.Tbl_EmployeeMaster
                       select new
                       {
                           employee.EmpID,
                           employee.EmployeeName
                       };
            return Json(data.ToList(), JsonRequestBehavior.AllowGet);
        }

        public JsonResult getEmployees(string sidx, string sord, int page, int rows, string searchString, string Supervisor_ID  = "2130")
        {
            //#1 Create Instance of DatabaseContext class for Accessing Database.  


            //#2 Setting Paging  
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;

            //#3 Linq Query to Get Customer  
            var Results = (from r in db.Tbl_Role
                           join ep in db.Tbl_EmployeeMaster on r.RoleID equals ep.Role




                           select new
                           {
                               ep.EmpID,
                               ep.EmployeeName,
                               ep.DOJ,
                               ep.Designation,
                               ep.MailID,
                               ep.ReportingPerson,
                               r.Role,
                               r.RoleID,



                           });

            //#4 Get Total Row Count  
            int totalRecords = Results.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

            //#5 Setting Sorting  
            if (sord.ToUpper() == "DESC")
            {
                Results = Results.OrderByDescending(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Results = Results.OrderBy(s => s.EmpID);
                Results = Results.Skip(pageIndex * pageSize).Take(pageSize);
            }
            //based on login employeeview
            if (!string.IsNullOrEmpty(Supervisor_ID))
            {
                Results = Results.Where(m => m.ReportingPerson == Supervisor_ID);
            }
            //#6 Setting Search  
            if (!string.IsNullOrEmpty(searchString))
            {
                Results = Results.Where(m => m.EmpID == searchString);
            }
            //#7 Sending Json Object to View.  
            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = Results
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);

        }

        public JsonResult employeesscores(string sidx, string sord, int page, int rows, string searchString)
        {
            //#1 Create Instance of DatabaseContext class for Accessing Database.  


            //#2 Setting Paging  
            int pageIndex = Convert.ToInt32(page) - 1;
            int pageSize = rows;

            //#3 Linq Query to Get Customer  
            var Result = (from es in db.Tbl_Employee_Score

                          select new
                 {
                     es.EmpID,
                     es.Category_Name,
                     es.Skill_Name,
                     es.Score_Rating,

                 });

            //#4 Get Total Row Count  
            int totalRecords = Result.Count();
            var totalPages = (int)Math.Ceiling((float)totalRecords / (float)rows);

            //#5 Setting Sorting  
            if (sord.ToUpper() == "DESC")
            {
                Result = Result.OrderByDescending(s => s.EmpID);
                Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
            }
            else
            {
                Result = Result.OrderBy(s => s.EmpID);
                Result = Result.Skip(pageIndex * pageSize).Take(pageSize);
            }
            //based on login employeeview
            //if (!string.IsNullOrEmpty(Supervisor_ID))
            //{
            //    Result = Result.Where(m => m.ReportingPerson == Supervisor_ID);
            //}
            //#6 Setting Search  
            if (!string.IsNullOrEmpty(searchString))
            {
                Result = Result.Where(m => m.EmpID == searchString);
            }
            //#7 Sending Json Object to View.  
            var jsonData = new
            {
                total = totalPages,
                page,
                records = totalRecords,
                rows = Result
            };
            return Json(jsonData, JsonRequestBehavior.AllowGet);

        }

        public string EditEmployee(Tbl_EmployeeMaster Employee, Tbl_Role Roless)
        {


            Employee.Role = (Roless.RoleID);




            string msg;
            try
            {

                if (ModelState.IsValid)
                {

                    db.Entry(Employee).State = EntityState.Modified;
                    db.SaveChanges();
                    msg = "Saved Successfully";

                }
                else
                {
                    msg = "Some Validation ";
                }
            }
            catch (Exception ex)
            {
                msg = "Error occured:" + ex.Message;
            }
            return msg;
        }
        //[HttpPost]
        //public JsonResult AddScores(  customers)
        //{
        //    StringBuilder msg = new StringBuilder();
        //    try
        //    {
        //        if (ModelState.IsValid)
        //        {
        //            using (DatabaseContext db = new DatabaseContext())
        //            {
        //                db.Customers.Add(customers);
        //                db.SaveChanges();
        //                return Json("Saved Successfully", JsonRequestBehavior.AllowGet);
        //            }
        //        }
        //        else
        //        {
        //            var errorList = (from item in ModelState
        //                             where item.Value.Errors.Any()
        //                             select item.Value.Errors[0].ErrorMessage).ToList();

        //            return Json(errorList, JsonRequestBehavior.AllowGet);
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        var errormessage = "Error occured: " + ex.Message;
        //        return Json(errormessage, JsonRequestBehavior.AllowGet);
        //    }

        //}  

    }
}