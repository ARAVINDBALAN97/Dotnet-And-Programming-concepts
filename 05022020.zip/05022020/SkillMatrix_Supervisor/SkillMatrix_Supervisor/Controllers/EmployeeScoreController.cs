﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SkillMatrix_Supervisor.Models;
using System.Data.Entity;

namespace SkillMatrix_Supervisor.Controllers
{
    public class EmployeeScoreController : Controller
    {
        //
        // GET: /EmployeeScore/
        public ActionResult Index()
        {


          
            return View();
        }
	}
}